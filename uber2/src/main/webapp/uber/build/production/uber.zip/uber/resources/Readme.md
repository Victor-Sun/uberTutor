# uber/resources

This folder contains resources (such as images) needed by the application. This file can
be removed if not needed.
